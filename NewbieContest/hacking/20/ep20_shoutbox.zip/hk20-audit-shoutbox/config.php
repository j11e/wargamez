<?php
/* Configuration de la base de donn�e */
$host="";
$login_bdd="";
$pass_bdd="";
$bd="";

/* Nombre de message a afficher dans la shootbox */
$nb_messages=5;
?>